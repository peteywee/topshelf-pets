---
title: "The First 48 Hours With a Puppy: A Calm-Start Checklist"
slug: "the-first-48-hours-with-a-puppy"
---
- Transport home safely (crate/carrier)
- Potty break on arrival; praise outside
- Quiet zone: crate + pen, water, chew
